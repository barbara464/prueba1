1. Servidor web vs servidor de aplicaciones o Investiga qué hace un servidor web (ej: Nginx, Apache) y en qué se
diferencia de un servidor de aplicaciones (ej: Gunicorn, uWSGI).

Respuesta: Servidor web (Nginx, Apache): se encarga de recibir peticiones HTTP, servir archivos estáticos (HTML, CSS, imágenes) y redirigir tráfico.
Servidor de aplicaciones (Gunicorn, uWSGI): ejecuta el código de la aplicación (Django, Flask, etc.), procesa la lógica y genera las respuestas dinámicas. 
Ejemplo: cuando entras a un restaurante online, Nginx sirve el HTML, y Gunicorn ejecuta Django para mostrar las reservas.

2. Protocolo DNS o Explica cómo traduce un nombre como reservasrestaurante.com en una dirección IP real.
Respuesta :Convierte un nombre de dominio (ej: reservasrestaurante.com) en una dirección IP real. 
Ejemplo: escribes reservasrestaurante.com, el DNS lo traduce a 172.217.3.110, y así tu navegador sabe a qué servidor conectarse

3. Modelo vs Vista en Django o Describe el rol de cada uno dentro del patrón MVT (Model-ViewTemplate).
Respuesta: Modelo (Model): representa los datos (ejemplo: Reserva con nombre, fecha, hora, personas).
Vista (View): contiene la lógica, decide qué datos mostrar y a qué template pasarlos. Ejemplo: el modelo guarda la reserva en la base de datos, la vista la lista y la pasa al template HTML.

4. HTTPS vs HTTP o Explica las ventajas de usar HTTPS en un sistema donde los clientes envían
datos sensibles.
REspuesta: HTTP: transmite datos en texto plano (poco seguro).
HTTPS: encripta la comunicación con SSL/TLS. Ventaja: cuando un cliente reserva mesa y escribe su nombre o correo, nadie puede interceptar los datos.